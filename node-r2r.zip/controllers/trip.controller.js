const { directionApiCall } = require('../helpers/helper');
const transferLib = require('../lib/transfer.lib');

class tripController {
    constructor() { }

    async drivingRoutes(params) {
        let finalRoutes = [];
        const result = await directionApiCall(data);
        if (result['routes'].length > 0) {
            $term = result['routes'][0]['legs'][0];
            finalRoutes = { type: 'car', distance: term['distance'], duration: term['duration'], start_address: term['start_address'], end_address: term['end_address'], overview_polyline: route['overview_polyline']['points'], start_place_id: result['geocoded_waypoints'][0]['place_id'], end_place_id: result['geocoded_waypoints'][1]['place_id'] };
        }
        console.log(finalRoutes);
        return finalRoutes;
    }

    async test(val) {
        console.log('welcome', val);
    }

    async combineRouteList(req, res) {

        try {
            // var responseData = { searchDetails: req.body };
            // responseData['routes'] = [];
            // var r=new Date(req.body.departure).getTime();
            // res.send(req.body.departure.split('T')[1]);
            // req.body.mode = 'transit';
            // const isTransferAvailable=await transferLib.hasLocation(req.body);
            // var drivingRoute = await directionApiCall(req.body); //1 s
            // res.send(drivingRoute);
            // res.send(isTransferAvailable);

            // if(isTransferAvailable){

            //     res.send(drivingRoute); 
            // }
            console.log(this.test(res),res);
            console.log(res);
            // const [isTransferAvailable, drivingRoute] = await Promise.all([transferLib.hasLocation(req.body), this.drivingRoutes(req.body)]);
            // if (isTransferAvailable) {
            //     responseData['routes'].push({ total_duration: drivingRoute['duration']['value'], first_stop: drivingRoute['start_address'], last_stop: drivingRoute['end_address'], modes: drivingRoute, overview_polyline: drivingRoute['overview_polyline'] });

            //     // res.send(drivingRoute);
            //     // drivingRoute['routes'].foreach((route) => {
            //     // })
            //     // let term = drivingRoute['routes'][0]['legs'][0];
            //     // res.send(term);
            // }

            // res.send({
            //     res_code: 200,
            //     response: "Success",
            //     data: ["ssdf"]
            // })

        } catch (error) {
            const stackLines = error.stack.split('\n');
            res.send({
                res_code: 201,
                response: "Something unexpected happened. Try again later.",
                server_message: error.message,
                line: stackLines[1].trim() ?? ''
            })

        }
    }
}

module.exports = new tripController();