const express = require('express');
const router = express.Router();
const decryption = require("../middlewares/decryption")
const encryption = require("../middlewares/encryption")

// router.use('/trip-planner', encryption, decryption, require("./trip.routes"));
router.use('/trip-planner', require("./trip.routes"));
// router.use('/api/v1/users', decryption, require("./user.routes"));
// router.use('/api/v1/holidays', encryption, decryption, require("./holiday.routes"));

module.exports = router;