const CryptoJS = require('crypto-js');

const decryption = (req, res, next) => {
    if(req.body.request_data){
        let decryptedData = CryptoJS.AES.decrypt(req.body.request_data, "aLtAeNCrypT").toString(
            CryptoJS.enc.Utf8
        );
        delete req.request_data;
        req.body = JSON.parse(decryptedData);
    }
    next();
}

module.exports = decryption