const CryptoJS = require('crypto-js');

const encryption = (req, res, next) => {

    var oldSend = res.json;
    // console.log(oldSend);
    
    res.json = function (data) {
        let encryptedData = CryptoJS.AES.encrypt(JSON.stringify(arguments[0]), "aLtAeNCrypT").toString();
        // console.log(arguments[0]);
        arguments[0] = { response_data: encryptedData };
        oldSend.apply(res, arguments);
    }
    next();
}

module.exports = encryption